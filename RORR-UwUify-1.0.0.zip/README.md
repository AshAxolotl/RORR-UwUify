# UwUify Risk of Rain Returns
Changes:
<ul>
  <li>"R" and "L" -> W </li>
  <li>the -> da </li>
  <li>they -> dey</li>
  <li>is -> ish</li>
</ul>
(if you have any ideas for what to change let me know)

## Instructions
1. Unzip the file
2. Place the uwu-engwish folder in your ```steamapps\common\Risk of Rain Returns\language\``` folder
3. Select the "UwU engwish" language option in the top right of the main menu.


## Credit:
The lang.json is a uwuified version of Slightly Better UI mod by x753
